=== Yandex.Metrika ===
Contributors: rdmitry
Tags: statistics,analytics
Tested up to: 3.5
Stable tag: 1.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Allow you to insert counter code for YandexMetrika to your blog.

== Description ==

Allow you to insert counter code for YandexMetrika to your blog.

Features:

* settings for place of counter code: header or footer
* settings for administators tracking

Плагин позволяет быстро и удобно добавлять счётчик Яндекс.Метрики в ваш блог.

Возможности:

* размещение счётчика в «заголовке» или «подвале»
* управление учётом администраторов сайта

== Installation ==

1. Unzip files.
2. Upload files to the '/wp-content/plugins/' directory.
3. Activate the plugin through the 'Plugins' menu in WordPress.

== Screenshots ==
1. Settings page