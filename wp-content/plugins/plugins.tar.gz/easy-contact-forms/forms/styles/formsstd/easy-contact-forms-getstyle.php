<?php
/**
 * @file
 * formsstd style loader.
 */
  $prodversion = defined('EASYCONTACTFORMS__prodVersion') ? '?ver=' . EASYCONTACTFORMS__prodVersion : '';
?><link href='<?php echo EASYCONTACTFORMS__engineWebAppDirectory;?>/forms/styles/formsstd/css/std.css<?php echo $prodversion;?>' rel='stylesheet' type='text/css'/><link href='<?php echo EASYCONTACTFORMS__engineWebAppDirectory;?>/forms/styles/formsstd/css/icons.css<?php echo $prodversion;?>' rel='stylesheet' type='text/css'/>